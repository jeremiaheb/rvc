# Reef Visual Census statistical package in R #

## Description ##
The rvc package is designed to compute summary statistics, such as: fish density, frequency of occurrence, and length frequencies for Reef Visual Census data, which can then be output to csv files or turned into graphs.

----
## Installation ##

### Using devtools (preferred) ###
Type the following into R
```
install.packages('devtools')
devtools::install_github('harryganz/rvc')
```
You can skip the first line if you already have devtools installed.

### Using base R ###
1. Download the compressed source folder named "rvc\_&lt;version&gt;.tar.gz" from the root directory of this project.
2. Type the following into R
```
install.packages('<path_to_file>/rvc_<version>.tar.gz', repos = NULL, type = "source")
require(rvc)
```

----
## Example Workflows ##

### Basic Workflow ###
```
library(rvc)

## Download desired Years/Regions data from server
keys11_14 = getRvcData(years = 2011:2014, regions = c("FLA KEYS", "DRTO"))

## Take a look at object structure
str(keys11_14, 1) # 3 data.frames

## Make a list of species
## You can use full scientific names, common names, or
## species codes (first 3 letters of genus, and first 4 of species)
## Only scientific names are case-sensitive
spcs = c("Epinephelus morio", "Black Grouper", "STE VARI")

## Calculate statistics for entire sampling domain
ddens = getDomainDensity(keys11_14, species = spcs)
dabun = getDomainAbundance(keys11_14, species = spcs)
docc = getDomainOccurrence(keys11_14, species = spcs)
```

### Using Filters ###
Filtering data can be used to select a subset of the data.
```
require(rvc)

## Get Data from the Florida Keys in 2011-2012
fk11_12 = getRvcData(years = 2011:2012, regions = "FLA KEYS")

## Use filters to change what data is selected
## Yellowtail occurrence in protected areas
yt_prot = getDomainOccurrence(fk11_12, species = "Ocyurus chrysurus", is_protected = TRUE)
## Red grouper density when present
rg_present = getDomainDensity(fk11_12, species = "Red Grouper", when_present = TRUE)
## Only select data from 2011
mut_2011 = getDomainAbundance(fk11_12, species = "Lut anal", years = 2011)
```

Available Filters:
1. strata: character vector of strata codes to keep.
2. status: character vector of protected statuses to keep.
3. is_protected: A boolean indicating whether only samples from protected areas should be kept (TRUE) or only unprotected areas (FALSE).
4. years: A numeric vector of years to keep.
5. regions: A character vector of region codes to keep. DRTO - Dry Tortugas, FLA KEYS: Florida Keys, SEFCRI - Southeast Peninsular Florida.
6. when_present: A boolean indicating whether only samples in which individuals are seen should be kept (TRUE) or not (FALSE). 
